import React, { useState, useMemo } from 'react';
import { List, Search, Play, Folder, Video as VideoIcon } from 'lucide-react';
import { useVideoData } from './hooks/useVideoData';
import { usePlaylistData } from './hooks/usePlaylistData';
import { Navigation } from './components/Navigation';
import { VideoGrid } from './components/VideoGrid';
import { SubgroupGrid } from './components/SubgroupGrid';
import { VideoPlayer } from './components/VideoPlayer';
import { PlaylistModal } from './components/PlaylistModal';
import { PlaylistPlayer } from './components/PlaylistPlayer';
import { PlaylistManager } from './components/PlaylistManager';
import { Breadcrumb } from './components/Breadcrumb';
import { YouTubeSearch } from './components/YouTubeSearch';
import { VideoLinkInput } from './components/VideoLinkInput';
import { Video, NavigationItem, Subgroup } from './types';

export default function App() {
  const { groups, loading, error } = useVideoData();
  const { 
    playlists, 
    createPlaylist, 
    addToPlaylist, 
    removeFromPlaylist, 
    deletePlaylist, 
    markAsWatched 
  } = usePlaylistData();
  
  const [currentPath, setCurrentPath] = useState<NavigationItem[]>([]);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [currentPlaylist, setCurrentPlaylist] = useState<any>(null);
  const [playlistModalVideo, setPlaylistModalVideo] = useState<Video | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentView, setCurrentView] = useState<'videos' | 'playlists' | 'search' | 'videolink'>('videos');
  const [isMobile, setIsMobile] = useState(false);

  // Check for mobile screen size
  React.useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth < 768) {
        setSidebarOpen(false);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const currentVideos = useMemo(() => {
    if (currentPath.length > 0) {
      const currentItem = currentPath[currentPath.length - 1];
      if (currentItem.subgroup && currentItem.subgroup.videos) {
        return currentItem.subgroup.videos;
      }
    }
    return [];
  }, [currentPath]);

  const currentSubgroups = useMemo(() => {
    if (currentPath.length === 0) {
      return groups.map(group => ({
        name: group.name,
        viewName: group.name,
        channelId: '',
        videos: [],
        subgroups: group.subgroups,
        isGroup: true,
        totalVideos: group.subgroups.reduce((total, subgroup) => {
          const countVideosInSubgroup = (sg: Subgroup): number => {
            const directVideos = sg.videos?.length || 0;
            const nestedVideos = sg.subgroups?.reduce((sum, nested) => sum + countVideosInSubgroup(nested), 0) || 0;
            return directVideos + nestedVideos;
          };
          return total + countVideosInSubgroup(subgroup);
        }, 0)
      }));
    }

    const currentItem = currentPath[currentPath.length - 1];
    if (currentItem.group) {
      return currentItem.group.subgroups || [];
    } else if (currentItem.subgroup && currentItem.subgroup.subgroups) {
      return currentItem.subgroup.subgroups;
    }
    
    return [];
  }, [groups, currentPath]);

  const filteredVideos = useMemo(() => {
    if (!searchQuery) return currentVideos;
    
    return currentVideos.filter(video =>
      video.snippet.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.snippet.channelTitle.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [currentVideos, searchQuery]);

  const handleCreatePlaylist = (name: string, videos: Video[] = []) => {
    const videosToAdd = videos.length > 0 ? videos : (playlistModalVideo ? [playlistModalVideo] : []);
    createPlaylist(name, videosToAdd);

    if (playlistModalVideo && videos.length === 0) {
      setPlaylistModalVideo(null);
    }
  };

  const handleAddToPlaylist = (playlistId: string, video: Video) => {
    addToPlaylist(playlistId, video);
  };

  const handleRemoveFromPlaylist = (playlistId: string, videoId: string) => {
    removeFromPlaylist(playlistId, videoId);
  };

  const handleDeletePlaylist = (playlistId: string) => {
    deletePlaylist(playlistId);
  };

  const handlePlayPlaylist = (playlist: any) => {
    setCurrentPlaylist(playlist);
    setCurrentVideo(null);
  };

  const handleUpdatePlaylist = (updatedPlaylist: any) => {
    setCurrentPlaylist(updatedPlaylist);
    // Mark videos as watched in database
    if (updatedPlaylist.watchedVideos) {
      for (const videoId of updatedPlaylist.watchedVideos) {
        markAsWatched(updatedPlaylist.id, videoId, true);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-xl">İçerik yükleniyor...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="text-red-400 text-xl mb-4">Hata: {error}</div>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg"
          >
            Yeniden Yükle
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 flex relative">
      {/* Sidebar */}
      <div className={`${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } fixed md:relative z-30 transition-transform duration-300 ease-in-out ${
        isMobile ? 'inset-y-0 left-0' : ''
      }`}>
        <Navigation
          groups={groups}
          currentPath={currentPath}
          onNavigate={setCurrentPath}
          onShowSearch={() => setCurrentView('search')}
          isSearchActive={currentView === 'search'}
          onShowVideoLink={() => setCurrentView('videolink')}
          isVideoLinkActive={currentView === 'videolink'}
          onClose={() => setSidebarOpen(false)}
          isMobile={isMobile}
        />
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && isMobile && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="bg-gray-800 p-3 md:p-4 border-b border-gray-700">
          <div className="flex items-center justify-between gap-2 md:gap-4">
            <div className="flex items-center space-x-2 md:space-x-4 min-w-0">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <List className="w-6 h-6" />
              </button>
              <h1 className="text-white text-lg md:text-xl font-bold truncate">Video Stream</h1>
            </div>
            
            <div className="flex items-center space-x-2 md:space-x-4 min-w-0">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Video ara..."
                  className="bg-gray-700 text-white pl-10 pr-4 py-2 rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none w-32 md:w-48 lg:w-64"
                />
              </div>
              
              <div className="flex bg-gray-700 rounded-lg overflow-hidden text-xs md:text-sm">
                <button
                  onClick={() => setCurrentView('videos')}
                  className={`px-2 md:px-4 py-2 transition-colors whitespace-nowrap ${
                    currentView === 'videos'
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  Videolar
                </button>
                <button
                  onClick={() => setCurrentView('search')}
                  className={`px-2 md:px-4 py-2 transition-colors whitespace-nowrap ${
                    currentView === 'search'
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  <Search className="w-3 h-3 md:w-4 md:h-4 inline mr-1" />
                  <span className="hidden sm:inline">YouTube </span>Ara
                </button>
                <button
                  onClick={() => setCurrentView('playlists')}
                  className={`px-2 md:px-4 py-2 transition-colors whitespace-nowrap ${
                    currentView === 'playlists'
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  <Play className="w-3 h-3 md:w-4 md:h-4 inline mr-1" />
                  <span className="hidden sm:inline">Listelerim </span>({playlists.length})
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-3 md:p-6 overflow-y-auto">
          {currentView === 'search' ? (
            <YouTubeSearch
              onAddToPlaylist={setPlaylistModalVideo}
            />
          ) : currentView === 'videolink' ? (
            <VideoLinkInput
              onPlayVideo={setCurrentVideo}
              onAddToPlaylist={setPlaylistModalVideo}
            />
          ) : currentView === 'videos' ? (
            <>
              <Breadcrumb path={currentPath} onNavigate={setCurrentPath} />
              
              {/* Show subgroups if available */}
              {currentSubgroups.length > 0 && (
                <SubgroupGrid
                  subgroups={currentSubgroups}
                  onNavigate={setCurrentPath}
                  currentPath={currentPath}
                />
              )}
              
              {/* Show welcome message only at root with no subgroups */}
              {currentPath.length === 0 && currentSubgroups.length === 0 && (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Folder className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg">Video kategorilerini keşfedin</p>
                    <p className="text-sm mt-2">Sol menüden bir kategori seçerek videoları görüntüleyebilirsiniz</p>
                  </div>
                </div>
              )}
              
              {/* Show videos if available */}
              {currentVideos.length > 0 && (
                <div className={currentSubgroups.length > 0 ? 'mt-8' : ''}>
                  {currentSubgroups.length > 0 && (
                    <h2 className="text-white text-xl font-bold mb-4 flex items-center">
                      <VideoIcon className="w-6 h-6 mr-2 text-blue-400" />
                      Videolar
                    </h2>
                  )}
                  <VideoGrid
                    videos={filteredVideos}
                    onPlayVideo={setCurrentVideo}
                    onAddToPlaylist={setPlaylistModalVideo}
                  />
                </div>
              )}
            </>
          ) : (
            <PlaylistManager
              playlists={playlists}
              onPlayPlaylist={handlePlayPlaylist}
              onRemoveFromPlaylist={handleRemoveFromPlaylist}
              onDeletePlaylist={handleDeletePlaylist}
              onAddVideoToPlaylist={setPlaylistModalVideo}
              onCreatePlaylist={handleCreatePlaylist}
            />
          )}
        </main>
      </div>

      {/* Video Player Modal */}
      <VideoPlayer
        video={currentVideo}
        onClose={() => setCurrentVideo(null)}
      />

      {/* Playlist Player */}
      <PlaylistPlayer
        playlist={currentPlaylist}
        onClose={() => setCurrentPlaylist(null)}
        onUpdatePlaylist={handleUpdatePlaylist}
      />

      {/* Playlist Modal */}
      <PlaylistModal
        video={playlistModalVideo}
        playlists={playlists}
        onClose={() => setPlaylistModalVideo(null)}
        onCreatePlaylist={handleCreatePlaylist}
        onAddToPlaylist={handleAddToPlaylist}
        onDeletePlaylist={handleDeletePlaylist}
      />
    </div>
  );
}