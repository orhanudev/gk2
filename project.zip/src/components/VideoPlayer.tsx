import React from 'react';
import ReactPlayer from 'react-player';
import { X } from 'lucide-react';
import { Video } from '../types';

interface VideoPlayerProps {
  video: Video | null;
  onClose: () => void;
}

export function VideoPlayer({ video, onClose }: VideoPlayerProps) {
  if (!video) return null;

  const videoId = video.id.videoId || video.id;
  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-lg w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex-1 min-w-0">
            <h2 className="text-white text-lg font-semibold truncate">
              {video.snippet.title}
            </h2>
            <p className="text-gray-400 text-sm truncate">
              {video.snippet.channelTitle}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors ml-4"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Video Player */}
        <div className="relative aspect-video bg-black">
          <ReactPlayer
            url='https://www.youtube.com/watch?v=ArmPzvHTcfQ'
            width="100%"
            height="100%"
            playing={true}
            controls={true}
            config={{
              youtube: {
                playerVars: {
                  autoplay: 1,
                  modestbranding: 1,
                  rel: 0
                }
              }
            }}
          />
        </div>

        {/* Description */}
        {video.snippet.description && (
          <div className="p-4 max-h-32 overflow-y-auto">
            <p className="text-gray-300 text-sm whitespace-pre-wrap">
              {video.snippet.description}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}